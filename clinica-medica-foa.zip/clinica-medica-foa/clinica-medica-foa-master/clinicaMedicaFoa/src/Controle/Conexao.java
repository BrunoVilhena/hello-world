package controle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexao {

    private static Connection con;

    public static Connection getConexao() {
        String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        try {
            Class.forName(driver);
            //con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=dbClinica;username=sa;password=foa");
            //con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=dbClinica;username=sa1;password=foa");
            con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=dbClinica;username=sa;password=etpc");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Driver não encontrado: " + e.getMessage(), "ERRO", 0);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro abrindo conex�o: " + e.getMessage(), "ERRO", 0);
        }
        return con;
    }
}
