/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

import java.sql.Date;

/**
 *
 * @author Markin Souza
 */
public class Consulta {
    private int codigo;
    private Date data;
    private String status;
    private String diagnostico;
//    private Date horaInicio;
//    private Date horaFim;
    private Horario horario;
    private Medico medico;
    private Cliente cliente;
   
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

//    public Date getHoraInicio() {
//        return horaInicio;
//    }
//
//    public void setHoraInicio(Date horaInicio) {
//        this.horaInicio = horaInicio;
//    }
//
//    public Date getHoraFim() {
//        return horaFim;
//    }
//
//    public void setHoraFim(Date horaFim) {
//        this.horaFim = horaFim;
//    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the horario
     */
    public Horario getHorario() {
        return horario;
    }

    /**
     * @param horario the horario to set
     */
    public void setHorario(Horario horario) {
        this.horario = horario;
    }

    
}
