/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

/**
 *
 * @author Markin Souza
 */
public enum FormaPagamento {

    CARTAO_CREDITO(1), CARTAO_DEBITO(2), A_VISTA(3), BOLETO(4), TRANSFERENCIA(5);

    public int formaPagamento;

    FormaPagamento(int formaPagamento) {
        this.formaPagamento = formaPagamento;
    }
    public int getFormaPagamento(){
        return formaPagamento;
    }
}
