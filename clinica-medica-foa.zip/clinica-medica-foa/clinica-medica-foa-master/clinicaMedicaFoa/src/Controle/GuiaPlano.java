/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

/**
 *
 * @author Markin Souza
 */
public class GuiaPlano {
    private int codigo;
    private String glossada;
    private String observacao;
    private Consulta consulta;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

   

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    /**
     * @return the consulta
     */
    public Consulta getConsulta() {
        return consulta;
    }

    /**
     * @param consulta the consulta to set
     */
    public void setConsulta(Consulta consulta) {
        this.consulta = consulta;
    }

    /**
     * @return the glossada
     */
    public String getGlossada() {
        return glossada;
    }

    /**
     * @param glossada the glossada to set
     */
    public void setGlossada(String glossada) {
        this.glossada = glossada;
    }
}
