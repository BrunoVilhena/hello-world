/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Fronteira;

import Controle.Cliente;
import Controle.Plano;
import Persistencia.perCliente;
import Persistencia.perFuncoes;
import Persistencia.perPlano;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;

/**
 *
 * @author Gladistone
 */
public class frmCliente extends javax.swing.JInternalFrame {
    ArrayList<Plano> aPlanos;
    ArrayList<Cliente> aClientes;
    /**
     * Creates new form frmCliente
     */
    public frmCliente() {
        initComponents();
    }
    
    private void habilitar(boolean bHabilitar){
       txtCpf.setEnabled(bHabilitar);
       txtNome.setEnabled(bHabilitar);
       txtDataNascimento.setEnabled(bHabilitar);
       cmbPlano.setEnabled(bHabilitar);
       btnGravar.setEnabled(bHabilitar);
       btnCancelar.setEnabled(bHabilitar);
       
       btnInserir.setEnabled(!bHabilitar);
       btnAlterar.setEnabled(!bHabilitar);
       btnDeletar.setEnabled(!bHabilitar);
       cmbConsulta.setEnabled(!bHabilitar);
       if(cmbConsulta.getSelectedIndex()==0){
           txtConsulta.setEnabled(false);
       }
       else{
           txtConsulta.setEnabled(!bHabilitar);
       }
       tblClientes.setEnabled(!bHabilitar);
       tblClientes.setRowSelectionAllowed(!bHabilitar);
    }

    private void limpar(){
        txtCpf.setText("");
        txtNome.setText("");
        txtDataNascimento.setText("");
        preencherComboPlano();
        lblOperacao.setText("");
    }
    
    private void preencherComboPlano(){
        aPlanos = perPlano.consultar("", "");
        cmbPlano.removeAllItems();
        cmbPlano.addItem("Selecione um Plano...");
        for(Plano item: aPlanos){
            cmbPlano.addItem(item.getCodigo() + " - " + item.getDescricao());
        }
    }
    
    private void preencherTabela(){
        String campo, valor;
        
        valor = txtConsulta.getText();
        switch(cmbConsulta.getSelectedIndex()){
            case 0: campo = ""; break;
            case 1: campo = "cpf"; valor = perFuncoes.soNumCpf(valor); break;
            case 2: campo = "nome"; break;
            case 3: campo = "dataNascimento"; break;
            case 4: campo = "plano"; break;
            default: campo = "";
        }
        
        
        aClientes = perCliente.consultar(campo, valor);
        
        DefaultTableModel modelo = (DefaultTableModel) tblClientes.getModel();
        modelo.setRowCount(0);
        
        for(Cliente linha: aClientes){
            String vetor[] = new String [4];
            vetor[0] = perFuncoes.mascaraCpf(linha.getCpf() + "");
            vetor[1] = linha.getNome();
            vetor[2] = perFuncoes.dateToString(linha.getDataNascimento());
            vetor[3] = linha.getPlano().getDescricao();
            modelo.addRow(vetor);
        }
        
        tblClientes.setModel(modelo);
    }
    
    private void carregarDados(int linha){
        limpar();
        txtCpf.setText(aClientes.get(linha).getCpf()+"");
        txtNome.setText(aClientes.get(linha).getNome());
        txtDataNascimento.setText(perFuncoes.dateToString(aClientes.get(linha).getDataNascimento()));
        selecionarPlanoCombo(aClientes.get(linha).getPlano().getCodigo());
    }
    
    private void selecionarPlanoCombo(int cod){
       int i;
       for(i=0;i<aPlanos.size();i++){
           if(aPlanos.get(i).getCodigo() == cod){
               cmbPlano.setSelectedIndex(i+1);
               break;
           }
       }
    }
    
    private void selecionarClienteTabela(long cpf){
        for(int linha = 0; linha < aClientes.size(); linha++){
            if(aClientes.get(linha).getCpf() == cpf){
                tblClientes.setRowSelectionInterval(linha, linha);
                break;
            }
        } 
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlFundo = new javax.swing.JPanel();
        lblPrincipal = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblClientes = new javax.swing.JTable();
        pnlDados = new javax.swing.JPanel();
        lblCpf = new javax.swing.JLabel();
        lblNome = new javax.swing.JLabel();
        txtCpf = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter cpf = new javax.swing.text.MaskFormatter("###.###.###-##");
            cpf.setPlaceholderCharacter('_');
            txtCpf = new javax.swing.JFormattedTextField(cpf);
        }
        catch (Exception e){
        }
        btnGravar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        lblOperacao = new javax.swing.JLabel();
        lblDataNascimento = new javax.swing.JLabel();
        txtDataNascimento = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        cmbPlano = new javax.swing.JComboBox<>();
        btnInserir = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();
        btnDeletar = new javax.swing.JButton();
        cmbConsulta = new javax.swing.JComboBox();
        txtConsulta = new javax.swing.JTextField();

        setClosable(true);
        setTitle("Clientes");
        setToolTipText("");
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });

        pnlFundo.setBackground(new java.awt.Color(204, 204, 204));

        lblPrincipal.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblPrincipal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPrincipal.setText("Clientes");

        tblClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CPF", "Nome", "Data Nascimento", "Plano"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblClientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblClientes);

        pnlDados.setBackground(new java.awt.Color(204, 204, 204));
        pnlDados.setBorder(javax.swing.BorderFactory.createTitledBorder("DADOS CADASTRAIS"));

        lblCpf.setText("CPF:");

        lblNome.setText("Nome:");

        btnGravar.setText("GRAVAR");
        btnGravar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGravarActionPerformed(evt);
            }
        });

        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        lblOperacao.setForeground(new java.awt.Color(0, 0, 204));
        lblOperacao.setText("     ");

        lblDataNascimento.setText("Nascimento:");

        try{
            javax.swing.text.MaskFormatter data = new javax.swing.text.MaskFormatter("##/##/####");
            data.setPlaceholderCharacter('_');
            txtDataNascimento = new javax.swing.JFormattedTextField(data);
        }
        catch (Exception e){
        }

        jLabel1.setText("Plano:");

        javax.swing.GroupLayout pnlDadosLayout = new javax.swing.GroupLayout(pnlDados);
        pnlDados.setLayout(pnlDadosLayout);
        pnlDadosLayout.setHorizontalGroup(
            pnlDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDadosLayout.createSequentialGroup()
                .addGroup(pnlDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlDadosLayout.createSequentialGroup()
                        .addGap(184, 184, 184)
                        .addComponent(btnGravar)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancelar))
                    .addGroup(pnlDadosLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pnlDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblNome)
                            .addComponent(lblDataNascimento)
                            .addComponent(lblCpf)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNome)
                            .addGroup(pnlDadosLayout.createSequentialGroup()
                                .addGroup(pnlDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlDadosLayout.createSequentialGroup()
                                        .addComponent(txtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblOperacao))
                                    .addComponent(txtDataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(cmbPlano, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        pnlDadosLayout.setVerticalGroup(
            pnlDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDadosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCpf)
                    .addComponent(txtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblOperacao))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNome)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDataNascimento)
                    .addComponent(txtDataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cmbPlano, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(pnlDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGravar)
                    .addComponent(btnCancelar))
                .addContainerGap())
        );

        btnInserir.setText("INSERIR");
        btnInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInserirActionPerformed(evt);
            }
        });

        btnAlterar.setText("ALTERAR");
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });

        btnDeletar.setText("DELETAR");
        btnDeletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeletarActionPerformed(evt);
            }
        });

        cmbConsulta.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Consultar...", "CPF", "Nome", "Nascimento", "Plano" }));
        cmbConsulta.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cmbConsultaItemStateChanged(evt);
            }
        });

        txtConsulta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtConsultaKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout pnlFundoLayout = new javax.swing.GroupLayout(pnlFundo);
        pnlFundo.setLayout(pnlFundoLayout);
        pnlFundoLayout.setHorizontalGroup(
            pnlFundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFundoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlFundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pnlFundoLayout.createSequentialGroup()
                        .addGroup(pnlFundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(pnlFundoLayout.createSequentialGroup()
                                .addComponent(cmbConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtConsulta))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnlFundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnAlterar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnInserir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnDeletar))))
                .addContainerGap())
        );
        pnlFundoLayout.setVerticalGroup(
            pnlFundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFundoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblPrincipal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlFundoLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(btnInserir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnAlterar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnDeletar)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnlDados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlFundo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlFundo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbConsultaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cmbConsultaItemStateChanged
        // TODO add your handling code here:
        txtConsulta.setText("");
        if(cmbConsulta.getSelectedIndex()==0){
           txtConsulta.setEnabled(false);
        }
        else{
            txtConsulta.setEnabled(true);
        }
        preencherTabela();
    }//GEN-LAST:event_cmbConsultaItemStateChanged

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        // TODO add your handling code here:
        if(tblClientes.getSelectedRow() == -1){
           JOptionPane.showMessageDialog(null,"Selecione um Cliente para alterar!","ERRO",JOptionPane.ERROR_MESSAGE); 
        }
        else{
            carregarDados(tblClientes.getSelectedRow());
            habilitar(true);
            txtCpf.setEnabled(false);
            lblOperacao.setText("ALTERAR");
            txtCpf.requestFocus();
        }
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened
        // TODO add your handling code here:
        habilitar(false);
        preencherComboPlano();
        preencherTabela();
    }//GEN-LAST:event_formInternalFrameOpened

    private void txtConsultaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtConsultaKeyReleased
        // TODO add your handling code here:
        preencherTabela();
    }//GEN-LAST:event_txtConsultaKeyReleased

    private void btnInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInserirActionPerformed
        // TODO add your handling code here:
        limpar();
        habilitar(true);
        lblOperacao.setText("INSERIR");
    }//GEN-LAST:event_btnInserirActionPerformed

    private void btnDeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeletarActionPerformed
        // TODO add your handling code here:
        if(tblClientes.getSelectedRow() == -1){
           JOptionPane.showMessageDialog(null,"Selecione um Cliente para deletar!","ERRO",JOptionPane.ERROR_MESSAGE); 
        }
        else{
            carregarDados(tblClientes.getSelectedRow());
            Object[] options = { "SIM", "NÃO" };
            int confirm = JOptionPane.showOptionDialog(null, 
                          "*Ao excluir o Cliente todas as Consultadas relacionadas e seus respectivos dados serão deletadas!\nVocê realmente deseja excluir o Plano: " + txtCpf.getText() + " - " + txtNome.getText() + "?", 
                          "EXCLUIR", 
                          JOptionPane.YES_NO_OPTION, 
                          JOptionPane.QUESTION_MESSAGE, null, options, options[1]);
            if (confirm == 0){
                if(perCliente.deletar(Long.parseLong(perFuncoes.soNumCpf(txtCpf.getText())))){
                   JOptionPane.showMessageDialog(null,"Excluído com sucesso!","SUCESSO",JOptionPane.INFORMATION_MESSAGE);
                   limpar();
                   preencherTabela();
                }
            }
        }
    }//GEN-LAST:event_btnDeletarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
        limpar();
        habilitar(false);
        if(tblClientes.getSelectedRow() > -1){
            carregarDados(tblClientes.getSelectedRow());
        }
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnGravarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGravarActionPerformed
        // TODO add your handling code here:
        Cliente cliente = new Cliente();
        cliente.setCpf(Long.parseLong(perFuncoes.soNumCpf(txtCpf.getText())));
        cliente.setNome(txtNome.getText());
        cliente.setDataNascimento(perFuncoes.stringToDate(txtDataNascimento.getText()));
        
        if(cmbPlano.getSelectedIndex()>0){
            cliente.setPlano(perPlano.consultarPlano(aPlanos.get(cmbPlano.getSelectedIndex()-1).getCodigo()));
        }
        else{
            cliente.setPlano(perPlano.consultarPlano(0));
        }
        
        if(lblOperacao.getText().equals("INSERIR")){
           if(perCliente.inserir(cliente)){
               JOptionPane.showMessageDialog(null,"Inserido com sucesso!", "SUCESSO", JOptionPane.INFORMATION_MESSAGE);
               cmbConsulta.setSelectedIndex(0);
               preencherTabela();
               selecionarClienteTabela(cliente.getCpf());
               btnCancelar.doClick();
           } 
        }
        else{
           if(perCliente.alterar(cliente)){
               JOptionPane.showMessageDialog(null,"Alterado com sucesso!", "SUCESSO", JOptionPane.INFORMATION_MESSAGE);
               cmbConsulta.setSelectedIndex(0);
               preencherTabela();
               selecionarClienteTabela(cliente.getCpf());
               btnCancelar.doClick();
           }
        }
    }//GEN-LAST:event_btnGravarActionPerformed

    private void tblClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblClientesMouseClicked
        // TODO add your handling code here:
        if(tblClientes.getSelectedRow() > -1 && tblClientes.getRowSelectionAllowed() == true ){
            carregarDados(tblClientes.getSelectedRow());
        }
    }//GEN-LAST:event_tblClientesMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnDeletar;
    private javax.swing.JButton btnGravar;
    private javax.swing.JButton btnInserir;
    private javax.swing.JComboBox cmbConsulta;
    private javax.swing.JComboBox<String> cmbPlano;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCpf;
    private javax.swing.JLabel lblDataNascimento;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblOperacao;
    private javax.swing.JLabel lblPrincipal;
    private javax.swing.JPanel pnlDados;
    private javax.swing.JPanel pnlFundo;
    private javax.swing.JTable tblClientes;
    private javax.swing.JTextField txtConsulta;
    private javax.swing.JTextField txtCpf;
    private javax.swing.JTextField txtDataNascimento;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
