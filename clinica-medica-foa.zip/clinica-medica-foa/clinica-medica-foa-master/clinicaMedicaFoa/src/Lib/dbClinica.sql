create database dbClinica
go
use dbClinica
go
create table Usuarios(
cpf bigint not null primary key,
nome varchar(100) not null,
senha varchar(10) not null,
crm bigint
)
go

create table Planos(
codigo int not null primary key identity(1,1),
descricao varchar(200) not null
)
go
create table Clientes(
cpf bigint not null primary key,
nome varchar(100) not null,
dataNascimento date not null,
plano int,
foreign key (plano) references Planos on delete cascade
)
go
create table Horarios(
codigo int not null primary key identity (1,1),
horaInicio date not null,
horaFim date not null
)
go
create table Consultas(
codigo int not null primary key identity(1,1),
data date not null,
situacao char(1) not null,
diagnostico varchar(300) not null,
cliente bigint not null,
horario int not null,
medico bigint not null,
foreign key (medico) references Usuarios on delete cascade,
foreign key (cliente) references Clientes on delete cascade,
foreign key (horario) references Horarios on delete cascade
)
go
create table GuiaPlanos(
codigo int not null primary key identity (1,1),
situacao char(1) not null,
observacao varchar(300),
consulta int not null,
foreign key (consulta) references Consultas on delete cascade
)
go
create table Exames(
codigo int not null primary key identity(1,1),
descricao varchar(300) not null,
resultado varchar(300) not null,
consulta int not null,
foreign key (consulta) references Consultas on delete cascade
)
go
create table PagamentoConsultas(
codigo int not null primary key identity (1,1),
data date not null,
desconto money not null,
banco varchar(50) not null,
agencia varchar(50) not null,
conta varchar(50) not null,
formaPagamento char(1) not null,
consulta int not null,
atendente bigint not null,
foreign key (consulta) references Consultas on delete cascade,
foreign key (atendente) references Usuarios
)
go
create table Pagamentos(
codigo int not null primary key identity(1,1),
data date not null,
valor money not null,
usuario bigint not null,
foreign key(usuario) references Usuarios on delete cascade
)
go
create table Ferias(
codigo int not null primary key identity(1,1),
dataInicio date not null,
dataFim date not null,
usuario bigint not null,
foreign key(usuario) references Usuarios on delete cascade
)
go
create table DiaAtendimentos(
codigo int not null primary key identity(1,1),
dia smallint not null,
horaInicio date not null,
horaFim date not null,
medico bigint not null,
foreign key (medico) references Usuarios on delete cascade
)
go
create table Ausencias(
codigo int not null primary key identity(1,1),
data date not null,
motivo varchar(300) not null,
diaAtendimento int not null,
foreign key (diaAtendimento) references DiaAtendimentos on delete cascade
)

insert into Horarios(horaInicio,horaFim) values ('06:00','06:30')
insert into Horarios(horaInicio,horaFim) values ('06:30','07:00')
insert into Horarios(horaInicio,horaFim) values ('07:00','07:30')
insert into Horarios(horaInicio,horaFim) values ('07:30','08:00')
insert into Horarios(horaInicio,horaFim) values ('08:00','08:30')
insert into Horarios(horaInicio,horaFim) values ('08:30','09:00')
insert into Horarios(horaInicio,horaFim) values ('09:00','09:30')
insert into Horarios(horaInicio,horaFim) values ('09:30','10:00')
insert into Horarios(horaInicio,horaFim) values ('10:00','10:30')
insert into Horarios(horaInicio,horaFim) values ('10:30','11:00')
insert into Horarios(horaInicio,horaFim) values ('11:00','11:30')
insert into Horarios(horaInicio,horaFim) values ('11:30','12:00')

insert into Horarios(horaInicio,horaFim) values ('12:00','12:30')
insert into Horarios(horaInicio,horaFim) values ('12:30','13:00')
insert into Horarios(horaInicio,horaFim) values ('13:00','13:30')
insert into Horarios(horaInicio,horaFim) values ('13:30','14:00')
insert into Horarios(horaInicio,horaFim) values ('14:00','14:30')
insert into Horarios(horaInicio,horaFim) values ('14:30','15:00')
insert into Horarios(horaInicio,horaFim) values ('15:00','15:30')
insert into Horarios(horaInicio,horaFim) values ('15:30','16:00')
insert into Horarios(horaInicio,horaFim) values ('16:00','16:30')
insert into Horarios(horaInicio,horaFim) values ('16:30','17:00')
insert into Horarios(horaInicio,horaFim) values ('17:00','17:30')
insert into Horarios(horaInicio,horaFim) values ('17:30','18:00')
insert into Horarios(horaInicio,horaFim) values ('18:00','18:30')

