/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Controle.Atendente;
import Controle.Medico;
import controle.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Gladistone
 */
public class perAtendente extends perUsuario {
    public static boolean inserir(Atendente atendente){
       String sql = "Insert Into Usuarios(cpf,nome,senha,crm) Values (?,?,?,?)";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setLong(1, atendente.getCpf());
          pst.setString(2, atendente.getNome());
          pst.setString(3, atendente.getSenha());
          pst.setNull(4, Types.LONGNVARCHAR);
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao inserir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
       return true; 
    }
    
    public static ArrayList<Atendente> consultar(String campo, String valor){
        String sql = "Select cpf, nome, senha From Usuarios Where crm Is Null";
      
      if(!campo.equals("")){
          sql = sql + " And " + campo + " like '" + valor + "%'";
      }
      
      sql = sql + " Order By descricao";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          ResultSet rst = pst.executeQuery();
          ArrayList<Atendente> listaAtendentes = new ArrayList<>();
          
          while(rst.next()){
              Atendente linhaAtendente = new Atendente();
              linhaAtendente.setCpf(rst.getLong(1));
              linhaAtendente.setNome(rst.getString(2));
              linhaAtendente.setSenha(rst.getString(3));
              listaAtendentes.add(linhaAtendente);
          }
          
          pst.close();
          conn.close();
          return listaAtendentes;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      }
    }
    
    public static Atendente consultarAtendente(long cpf){
      String sql = "Select cpf, nome, senha From Usuarios Where cpf = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          
          pst.clearParameters();
          pst.setLong(1, cpf);
          
          ResultSet rst = pst.executeQuery();
          
          Atendente atendente = new Atendente();
          if(rst.next()){
              atendente.setCpf(rst.getLong(1));
              atendente.setNome(rst.getString(2));
              atendente.setSenha(rst.getString(3));
          }
          
          pst.close();
          conn.close();
          return atendente;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar Plano: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      } 
   }
    
   public static boolean alterar(Atendente atendente){
      String sql = "Update Usuarios Set nome = ?, senha = ? Where cpf = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setString(1, atendente.getNome());
          pst.setString(2, atendente.getSenha());
          pst.setLong(3, atendente.getCpf());
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao alterar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
   }
   
   public static boolean deletar(long cpf){
      String sql = "Delete From Usuarios Where cpf = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setLong(1, cpf);
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao excluir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
   }
}
