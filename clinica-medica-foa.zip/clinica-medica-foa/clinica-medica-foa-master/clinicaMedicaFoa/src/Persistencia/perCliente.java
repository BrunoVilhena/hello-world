/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Controle.Cliente;
import controle.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class perCliente {
    
    public static boolean inserir(Cliente cliente){
      String sql = "Insert Into Clientes(cpf,nome,dataNascimento,plano) Values (?,?,?,?)";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setLong(1, cliente.getCpf());
          pst.setString(2, cliente.getNome());
          pst.setDate(3, new java.sql.Date(cliente.getDataNascimento().getTime()));
          
          if(cliente.getPlano().getCodigo() == 0){
              pst.setNull(4, Types.INTEGER);
          }
          else{
              pst.setInt(4, cliente.getPlano().getCodigo());
          }
          
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao inserir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
   }
    
   public static ArrayList<Cliente> consultar(String campo, String valor){
      String sql = "Select cpf, nome, dataNascimento, plano From Clientes";
      
      if(!campo.equals("")){
          
          if(campo.equals("plano")){
              sql = sql + " Left Join Planos On Clientes.plano = Planos.codigo Where Planos.descricao like '" + valor + "%'";
          }
          else{
              sql = sql + " Where " + campo + " like '" + valor + "%'";
          }
      }
      
      sql = sql + " Order By nome";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          ResultSet rst = pst.executeQuery();
          ArrayList<Cliente> listaClientes = new ArrayList<>();
          
          while(rst.next()){
              Cliente linhaCliente = new Cliente();
              linhaCliente.setCpf(rst.getLong(1));
              linhaCliente.setNome(rst.getString(2));
              linhaCliente.setDataNascimento(rst.getDate(3));
              linhaCliente.setPlano(perPlano.consultarPlano(rst.getInt(4)));
              listaClientes.add(linhaCliente);
          }
          
          pst.close();
          conn.close();
          return listaClientes;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      }
       
   } 

   public static Cliente consultarCliente(long cpf){
      String sql = "Select cpf, nome, dataNascimento, plano From Clientes Where cpf = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          
          pst.clearParameters();
          pst.setLong(1, cpf);
          
          ResultSet rst = pst.executeQuery();
          
          Cliente cliente = new Cliente();
          if(rst.next()){
              cliente.setCpf(rst.getLong(1));
              cliente.setNome(rst.getString(2));
              cliente.setDataNascimento(rst.getDate(3));
              cliente.setPlano(perPlano.consultarPlano(rst.getInt(4)));
          }
          
          pst.close();
          conn.close();
          return cliente;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar Plano: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      } 
   }
   
   public static boolean alterar(Cliente cliente){
      String sql = "Update Clientes Set nome = ?, dataNascimento = ?, plano = ? Where cpf = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setString(1, cliente.getNome());
          pst.setDate(2, new java.sql.Date(cliente.getDataNascimento().getTime()));
          
          if(cliente.getPlano().getCodigo() == 0){
              pst.setNull(3, Types.INTEGER);
          }
          else{
              pst.setInt(3, cliente.getPlano().getCodigo());
          }
          pst.setLong(4, cliente.getCpf());
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao alterar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
   }
   
   public static boolean deletar(long cpf){
      String sql = "Delete From Clientes Where cpf = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setLong(1, cpf);
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao excluir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
   }
      
   
}
