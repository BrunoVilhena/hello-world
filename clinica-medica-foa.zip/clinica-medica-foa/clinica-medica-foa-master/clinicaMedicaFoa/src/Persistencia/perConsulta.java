/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Controle.Consulta;
import controle.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author bruno
 */
public class perConsulta {
    
    public static boolean inserir(Consulta consulta){
        String sql = "insert into Consultas(data,situacao,diagnostico,cliente,horario,medico) values (?,?,?,?,?,?)";
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst  = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setDate(1, new java.sql.Date(consulta.getData().getTime()));
            pst.setString(2, consulta.getStatus());
            pst.setString(3,consulta.getDiagnostico());
            pst.setLong(4,consulta.getCliente().getCpf());
            pst.setInt(5, consulta.getHorario().getCodigo());
            pst.setLong(6,consulta.getMedico().getCpf());
            pst.executeUpdate();
            pst.close();
            conn.close();
                    
        }catch(SQLException e ){
          JOptionPane.showMessageDialog(null,"Erro ao inserir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
        }
        return true;
    }
    
    public static ArrayList<Consulta> consultar(String campo,String valor){
        String sql = "select codigo,data,situacao,diagnostico,cliente,horario,medico from Consultas";
        
        if(!campo.equals("")){
            
            if(campo.equals("cliente")){
                sql = sql + "Left Join Clientes on Consulta.cliente = Clientes.cpf where Clientes.nome like '" + valor + "%'";
            }
            else{
                if(campo.equals("medico")){
                    sql = sql + "Left Join Usuarios on Consulta.medico = Usuarios.cpf where Usuarios.nome like '" + valor + "%'";
                }
                else{
                    sql = sql + " where " + campo + " like '" + valor + "%'"; 
                }
            }
            
            sql = sql + "Order by data";
                
        }
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rst = pst.executeQuery();
            ArrayList<Consulta> listaConsultas = new ArrayList<>();
            while(rst.next()){
                Consulta linhaConsulta = new Consulta();
                linhaConsulta.setCodigo(rst.getInt(1));
                linhaConsulta.setData(rst.getDate(2));
                linhaConsulta.setStatus(rst.getString(3));
                linhaConsulta.setDiagnostico(rst.getString(4));
                linhaConsulta.setCliente(perCliente.consultarCliente(rst.getLong(5)));
                linhaConsulta.setHorario(perHorario.consultarHorario(rst.getInt(6)));
                linhaConsulta.setMedico(perMedico.consultarMedico(rst.getLong(7)));
                listaConsultas.add(linhaConsulta);
            }
            pst.close();
            conn.close();
            return listaConsultas;
            
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
        }
       
    }
    public static Consulta consultarConsulta(int codigo){
        String sql = "Select codigo,data,situacao,diagnostico,cliente,horario,medico from Consultas where codigo = ?";
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setInt(1,codigo);
            ResultSet rst= pst.executeQuery();
            Consulta consulta = new Consulta();
            if(rst.next()){
                consulta.setCodigo(rst.getInt(1));
                consulta.setData(rst.getDate(2));
                consulta.setStatus(rst.getString(3));
                consulta.setDiagnostico(rst.getString(4));
                consulta.setCliente(perCliente.consultarCliente(rst.getLong(5)));
                consulta.setHorario(perHorario.consultarHorario(rst.getInt(6)));
                consulta.setMedico(perMedico.consultarMedico(rst.getLong(7)));
            }
            pst.close();
            conn.close();
            return consulta;
            
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
        }
    }
    public static boolean alterar(Consulta consulta){
        String sql="Update Consulta Set data = ?, situacao = ?, diagnostico = ?, cliente = ?, horario = ?, medico = ? Where codigo = ?";
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setDate(1, new java.sql.Date(consulta.getData().getTime()));
            pst.setString(2, consulta.getStatus());
            pst.setString(3,consulta.getDiagnostico());
            pst.setLong(4,consulta.getCliente().getCpf());
            pst.setInt(5, consulta.getHorario().getCodigo());
            pst.setLong(6,consulta.getMedico().getCpf());
            pst.setInt(7, consulta.getCodigo());
            pst.executeUpdate();
            pst.close();
            conn.close();
            
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erro ao alterar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
        }
        
        return true;
    }
    
    public static boolean deletar(int codigo){
        String sql= "Delete from Consulta Where codigo = ?";
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setInt(1, codigo);
            pst.executeUpdate();
            pst.close();
            conn.close();
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erro ao deletar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
        }
        return true;
    }
            
}
