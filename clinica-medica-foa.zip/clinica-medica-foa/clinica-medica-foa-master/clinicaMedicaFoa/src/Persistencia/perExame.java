/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Controle.Exame;
import controle.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author bruno
 */
public class perExame {
    
    public static boolean inserir(Exame exame){
        String sql="Insert Into Exames (descricao, resultado, consulta) values (?,?,?) ";
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setString(1,exame.getDescricao());
            pst.setString(2, exame.getResultado());
            pst.setInt(3, exame.getConsulta().getCodigo());
            pst.executeUpdate();
            pst.close();
            conn.close();
            
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erro ao inserir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
        }
        
        return true;
    }
    
    public static ArrayList<Exame> consultar(String campo, String valor){
        String sql = "Select codigo, descricao, resultado, consulta From Exames";
        if(!campo.equals("")){
          
//          if(campo.equals("consulta")){
//              sql = sql + " Left Join Consultas On Exames.consulta = Consultas.codigo Where Consulta.? like '" + valor + "%'";
//          }
//          else{
              sql = sql + " Where " + campo + " like '" + valor + "%'";
         // }
      }
      
      //sql = sql + " Order By codigo";
      
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rst = pst.executeQuery();
            ArrayList<Exame> listaExames = new ArrayList<>();
            while(rst.next()){
                Exame linhaExame = new Exame();
                linhaExame.setCodigo(rst.getInt(1));
                linhaExame.setDescricao(rst.getString(2));
                linhaExame.setResultado(rst.getString(3));
                linhaExame.setConsulta(perConsulta.consultarConsulta(rst.getInt(4)));
                listaExames.add(linhaExame);
            }
            pst.close();
            conn.close();
            return listaExames;
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
    
    public static boolean alterar(Exame exame){
        String sql = "Update Exames Set descricao = ?, resultado = ?, consulta = ? Where codigo = ?";
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setString(1,exame.getDescricao());
            pst.setString(2, exame.getResultado());
            pst.setInt(3, exame.getConsulta().getCodigo());
            pst.setInt(4,exame.getCodigo());
            pst.executeUpdate();
            pst.close();
            conn.close();
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erro ao alterar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
        }
        
        return true;
    }
    
    public static boolean deletar(int codigo){
        String sql = "Delete from Exames Where codigo =?";
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setInt(1, codigo);
            pst.executeUpdate();
            pst.close();
            conn.close();
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erro ao deletar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
        }
        
        return true;
    }
}
