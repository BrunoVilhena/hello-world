/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Controle.Ferias;
import controle.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author bruno
 */
public class perFerias {
    public static boolean inserir(Ferias ferias){
        String sql = "Insert into Ferias (dataInicio, dataFim, usuario) Values (?,?,?)";
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setDate(1, new java.sql.Date(ferias.getDataInicio().getTime()));
            pst.setDate(2, new java.sql.Date(ferias.getDataFim().getTime()));
            pst.setLong(3, ferias.getMedico().getCpf());
            pst.executeUpdate();
            pst.close();
            conn.close();
          
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao inserir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
    }
    
    public static ArrayList<Ferias> consultar(String campo, String valor){
        String sql = "Select codigo, dataInicio, dataFim, usuario From Ferias";
        if(!campo.equals("")){
          
          if(campo.equals("medico")){
              sql = sql + " Left Join Usuarios On Ferias.usuario = Usuarios.cpf Where Usuarios.nome like '" + valor + "%'";
          }
          else{
              sql = sql + " Where " + campo + " like '" + valor + "%'";
          }
      }
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rst = pst.executeQuery();
            ArrayList<Ferias> listaFerias = new ArrayList<>();
            while(rst.next()){
                Ferias linhaFerias = new Ferias();
                linhaFerias.setCodigo(rst.getInt(1));
                linhaFerias.setDataInicio(rst.getDate(2));
                linhaFerias.setDataFim(rst.getDate(3));
                linhaFerias.setMedico(perMedico.consultarMedico(rst.getLong(4)));
                listaFerias.add(linhaFerias);
            }
            pst.close();
            conn.close();
            return listaFerias;
            
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      }
    }
    
    public static boolean alterar(Ferias ferias){
        String sql = "Update Feias Set dataInicio = ?, dataFim = ?, usuario = ? Where codigo = ?";
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setDate(1, new java.sql.Date(ferias.getDataInicio().getTime()));
            pst.setDate(2, new java.sql.Date(ferias.getDataFim().getTime()));
            pst.setLong(3, ferias.getMedico().getCpf());
            pst.setInt(4, ferias.getCodigo());
            pst.executeUpdate();
            pst.close();
            conn.close();            
            
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao alterar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
    }
    
    public static boolean deletar(int codigo){
        String sql = "Delete from Ferias Where codigo = ?";
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setInt(1, codigo);
            pst.executeUpdate();
            pst.close();
            conn.close();
            
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao excluir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
                
    }
}
