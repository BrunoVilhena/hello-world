/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class perFuncoes {
    public static Date stringToDate(String data){
       SimpleDateFormat formataData = new SimpleDateFormat("dd/MM/yyyy"); 
       formataData.setLenient(false);
        try {
            Date vData = formataData.parse(data);
            return vData;
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null,"Data inválida");
            return null;
        }
    }
    
    public static String dateToString(Date data){
       SimpleDateFormat formataData = new SimpleDateFormat("dd/MM/yyyy"); 
       formataData.setLenient(false);
       String sData =  formataData.format(data);
       return sData;
    }
    
    public static String soNumCpf(String cpf){
        cpf = cpf.replaceAll("_", "");
        cpf = cpf.replaceAll("\\.", "");
        cpf = cpf.replaceAll("-","");
        return cpf;
    }
    
    public static String mascaraCpf(String cpf){
        return cpf.replaceAll("(\\d{3})(\\d{3})(\\d{3})(\\d{2})","$1.$2.$3-$4");
    }
}
