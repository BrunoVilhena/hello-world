/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Controle.GuiaPlano;
import controle.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author bruno
 */
public class perGuiaPlano {
    
    public static boolean inserir(GuiaPlano guiaPlano){
        String sql = "Insert Into GuiaPlanos (situacao,observacao,consulta) Values(?,?,?) ";
             
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setString(1, guiaPlano.getGlossada());
            pst.setString(2, guiaPlano.getObservacao());
            pst.setInt(3,guiaPlano.getConsulta().getCodigo());
            pst.executeUpdate();
            pst.close();
            conn.close();
            
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao inserir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
    }
    
    public static ArrayList<GuiaPlano> consultar(String campo, String valor){
        String sql = "Select codigo, situacao, observacao, consulta From GuiaPlanos";
        if(!campo.equals("")){
          
            sql = sql + " Where " + campo + " like '" + valor + "%'";
         }
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rst = pst.executeQuery();
            ArrayList<GuiaPlano> listaGuiaPlanos = new ArrayList<>();
            while(rst.next()){
                GuiaPlano linhaGuiaPlano = new GuiaPlano();
                linhaGuiaPlano.setCodigo(rst.getInt(1));
                linhaGuiaPlano.setGlossada(rst.getString(2));
                linhaGuiaPlano.setObservacao(rst.getString(3));
                linhaGuiaPlano.setConsulta(perConsulta.consultarConsulta(rst.getInt(4)));
                listaGuiaPlanos.add(linhaGuiaPlano);
            }
            pst.close();
            conn.close();
            return listaGuiaPlanos;
            
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      }
    }
    
    public static boolean alterar(GuiaPlano guiaPlano){
        String sql = "Update GuiaPlanos Set situacao = ?, observacao = ?, consulta = ? Where codigo = ?";
        try{
             Connection conn = Conexao.getConexao();
             PreparedStatement pst = conn.prepareStatement(sql);
             pst.clearParameters();
             pst.setString(1, guiaPlano.getGlossada());
             pst.setString(2, guiaPlano.getObservacao());
             pst.setInt(3,guiaPlano.getConsulta().getCodigo());
             pst.setInt(4,guiaPlano.getCodigo());
             
             pst.executeUpdate();
             pst.close();
             conn.close();
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao alterar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
    }
}
