/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Controle.Horario;
import controle.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author bruno
 */
public class perHorario {
    
      public static ArrayList<Horario> consultar(Horario horario){
          String sql = "select codigo,horarioInicio,horarioFim From Horarios";
          
          try{
              Connection conn = Conexao.getConexao();
              PreparedStatement pst = conn.prepareStatement(sql);
              ResultSet rst = pst.executeQuery();
              ArrayList<Horario> listaHorario = new ArrayList<>();
              while(rst.next()){
                  Horario linhaHorario = new Horario();
                  linhaHorario.setCodigo(rst.getInt(1));
                  linhaHorario.setHoraInicio(rst.getDate(2));
                  linhaHorario.setHoraInicio(rst.getDate(3));
                  listaHorario.add(linhaHorario);
              }
              pst.close();
              conn.close();
              return listaHorario;
              
          }catch(SQLException e){
              JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
              return null;
          }
      }  
      public static Horario consultarHorario(int codigo){
      String sql = "Select codigo,horaInicio, horaFim  From Horarios Where codigo = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          
          pst.clearParameters();
          pst.setLong(1, codigo);
          
          ResultSet rst = pst.executeQuery();
          
          Horario horario = new Horario();
          if(rst.next()){
              horario.setCodigo(rst.getInt(1));
              horario.setHoraInicio(rst.getDate(2));
              horario.setHoraFim(rst.getDate(3));
              
          }
          
          pst.close();
          conn.close();
          return horario;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      } 
   }
    
}
