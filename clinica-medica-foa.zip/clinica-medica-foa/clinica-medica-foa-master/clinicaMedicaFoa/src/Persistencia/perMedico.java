/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Controle.Medico;
import controle.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Gladistone
 */
public class perMedico extends perUsuario {
    
    public static boolean inserir(Medico medico){
       String sql = "Insert Into Usuarios(cpf,nome,senha,crm) Values (?,?,?,?)";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setLong(1, medico.getCpf());
          pst.setString(2, medico.getNome());
          pst.setString(3, medico.getSenha());
          pst.setLong(4, medico.getCrm());
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao inserir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
       return true; 
    }
    
    public static ArrayList<Medico> consultar(String campo, String valor){
        String sql = "Select cpf, nome, crm, senha From Usuarios Where crm Is Not Null";
      
      if(!campo.equals("")){
          sql = sql + " And " + campo + " like '" + valor + "%'";
      }
      
      sql = sql + " Order By descricao";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          ResultSet rst = pst.executeQuery();
          ArrayList<Medico> listaMedicos = new ArrayList<>();
          
          while(rst.next()){
              Medico linhaMedico = new Medico();
              linhaMedico.setCpf(rst.getLong(1));
              linhaMedico.setNome(rst.getString(2));
              linhaMedico.setCrm(rst.getLong(3));
              linhaMedico.setSenha(rst.getString(4));
              listaMedicos.add(linhaMedico);
          }
          
          pst.close();
          conn.close();
          return listaMedicos;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      }
    }
    
    public static Medico consultarMedico(long cpf){
      String sql = "Select cpf, nome, crm, senha From Usuarios Where cpf = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          
          pst.clearParameters();
          pst.setLong(1, cpf);
          
          ResultSet rst = pst.executeQuery();
          
          Medico medico = new Medico();
          if(rst.next()){
              medico.setCpf(rst.getLong(1));
              medico.setNome(rst.getString(2));
              medico.setCrm(rst.getLong(3));
              medico.setSenha(rst.getString(4));
          }
          
          pst.close();
          conn.close();
          return medico;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar Plano: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      } 
   }
    
   public static boolean alterar(Medico medico){
      String sql = "Update Usuarios Set nome = ?, crm = ?, senha = ? Where cpf = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setString(1, medico.getNome());
          pst.setLong(2, medico.getCrm());
          pst.setString(3, medico.getSenha());
          pst.setLong(4, medico.getCpf());
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao alterar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
   }
   
   public static boolean deletar(long cpf){
      String sql = "Delete From Usuarios Where cpf = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setLong(1, cpf);
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao excluir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
   }
   
}
