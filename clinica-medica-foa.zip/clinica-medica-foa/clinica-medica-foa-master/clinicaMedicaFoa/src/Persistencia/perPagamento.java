/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Controle.Pagamento;
import controle.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author bruno
 */
public class perPagamento {
    
    public static boolean inserir(Pagamento pagamento){
        String sql = "Insert Into Pagamentos (data, valor, usuario) Values (?,?,?)";
        try{
             Connection conn = Conexao.getConexao();
             PreparedStatement pst = conn.prepareStatement(sql);
             pst.clearParameters();
             pst.setDate(1, new java.sql.Date(pagamento.getData().getTime()));
             pst.setDouble(2, pagamento.getValor());
             pst.setLong(3, pagamento.getMedico().getCpf());
             pst.executeUpdate();
             pst.close();
             conn.close();
            
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao inserir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
    }
    
    public static ArrayList<Pagamento> consultar(String campo, String valor){
        String sql = "Select codigo, data, valor, usuario From Pagamentos ";
        if(!campo.equals("")){
                if(campo.equals("medico")){
                    sql = sql + "Left Join Usuarios on Consulta.medico = Usuarios.cpf where Usuarios.nome like '" + valor + "%'";
                }
                else{
                    sql = sql + " where " + campo + " like '" + valor + "%'"; 
                }
            
        }
        sql = sql + "Order by data";
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rst = pst.executeQuery();
            ArrayList<Pagamento> listaPagamentos = new ArrayList<>();
            while(rst.next()){
                Pagamento linhaPagamento = new Pagamento();
                linhaPagamento.setCodigo(rst.getInt(1));
                linhaPagamento.setData(rst.getDate(2));
                linhaPagamento.setValor(rst.getDouble(3));
                linhaPagamento.setMedico(perMedico.consultarMedico(rst.getLong(4)));
                listaPagamentos.add(linhaPagamento);
            }
            pst.close();
            conn.close();
            return listaPagamentos;
            
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      }
             
    }
    
    public static boolean alterar(Pagamento pagamento){
        String sql = "Update Pagamentos Set data = ?, valor = ?, usuario = ? Where codigo = ?";
        try{
             Connection conn = Conexao.getConexao();
             PreparedStatement pst = conn.prepareStatement(sql);
             pst.clearParameters();
             pst.setDate(1, new java.sql.Date(pagamento.getData().getTime()));
             pst.setDouble(2, pagamento.getValor());
             pst.setLong(3, pagamento.getMedico().getCpf());
             pst.setInt(4, pagamento.getCodigo());
             pst.executeUpdate();
             pst.close();
             conn.close();
             
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao alterar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
    }   
    
}
