/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Controle.PagamentoConsulta;
import controle.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author bruno
 */
public class perPagamentoConsulta {
    
     public static boolean inserir(PagamentoConsulta pagamentoConsulta){
        String sql = "Insert Into  PagamentoConsultas (data, desconto, banco, agencia, conta, formaPagamento, consulta, atendente) Values(?,?,?,?,?,?,?,?) ";
             
        try{
            Connection conn = Conexao.getConexao();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.clearParameters();
            pst.setDate(1, new java.sql.Date(pagamentoConsulta.getData().getTime()));
            pst.setDouble(2, pagamentoConsulta.getDesconto());
            pst.setString(3, pagamentoConsulta.getBanco());
            pst.setString(4, pagamentoConsulta.getAgencia());
            pst.setString(5, pagamentoConsulta.getConta());
            pst.setInt(6, pagamentoConsulta.getFormaPagamento());
            pst.setInt(7,pagamentoConsulta.getConsulta().getCodigo());
            pst.setLong(8, pagamentoConsulta.getAtendente().getCpf());
            pst.executeUpdate();
            pst.close();
            conn.close();
            
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao inserir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
    }
     
     public static ArrayList<PagamentoConsulta> consultar(String campo, String valor){
         String sql = "Select codigo, data, desconto, banco, agencia, conta, formaPagamento, consulta, atendente From PagamentoConsultas";
      
      if(!campo.equals("")){
          
          if(campo.equals("atendente")){
              sql = sql + " Left Join Usuarios On PagamentoConsultas.atendente = Usuarios.cpf Where Usuarios.nome like '" + valor + "%'";
          }
          else{
              sql = sql + " Where " + campo + " like '" + valor + "%'";
          }
      }
      
      sql = sql + " Order By data";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          ResultSet rst = pst.executeQuery();
          ArrayList<PagamentoConsulta> listaPagamentoConsulta = new ArrayList<>();
          
          while(rst.next()){
              PagamentoConsulta linhaPagamentoConsulta = new PagamentoConsulta();
              linhaPagamentoConsulta.setCodigo(rst.getInt(1));
              linhaPagamentoConsulta.setData(rst.getDate(2));
              linhaPagamentoConsulta.setDesconto(rst.getDouble(3));
              linhaPagamentoConsulta.setBanco(rst.getString(4));
              linhaPagamentoConsulta.setAgencia(rst.getString(5));
              linhaPagamentoConsulta.setConta(rst.getString(6));
              linhaPagamentoConsulta.setFormaPagamento(rst.getInt(7));
              linhaPagamentoConsulta.setConsulta(perConsulta.consultarConsulta(rst.getInt(8)));
              linhaPagamentoConsulta.setAtendente(perAtendente.consultarAtendente(rst.getLong(9)));
              listaPagamentoConsulta.add(linhaPagamentoConsulta);            
                      
          }
          
          pst.close();
          conn.close();
          return listaPagamentoConsulta;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      }
 } 
      public static boolean alterar(PagamentoConsulta pagamentoConsulta){
      String sql = "Update PagamentoConsulras Set data = ?, desconto = ?, banco = ?, agencia = ?, conta = ?, formaPagamento = ?, consulta = ?, atendente = ? Where codigo = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setDate(1, new java.sql.Date(pagamentoConsulta.getData().getTime()));
          pst.setDouble(2, pagamentoConsulta.getDesconto());
          pst.setString(3, pagamentoConsulta.getBanco());
          pst.setString(4, pagamentoConsulta.getAgencia());
          pst.setString(5, pagamentoConsulta.getConta());
          pst.setInt(6, pagamentoConsulta.getFormaPagamento());
          pst.setInt(7,pagamentoConsulta.getConsulta().getCodigo());
          pst.setLong(8, pagamentoConsulta.getAtendente().getCpf());
          pst.setInt(9,pagamentoConsulta.getCodigo());
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao alterar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
      }
} 


