/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Controle.Plano;
import controle.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class perPlano {
    
   public static boolean inserir(Plano plano){
      String sql = "Insert Into Planos(descricao) Values (?)";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setString(1, plano.getDescricao());
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao inserir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
   }
   
   public static ArrayList<Plano> consultar(String campo, String valor){
      String sql = "Select codigo, descricao From Planos";
      
      if(!campo.equals("")){
          sql = sql + " Where " + campo + " like '" + valor + "%'";
      }
      
      sql = sql + " Order By descricao";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          ResultSet rst = pst.executeQuery();
          ArrayList<Plano> listaPlanos = new ArrayList<>();
          
          while(rst.next()){
              Plano linhaPlano = new Plano();
              linhaPlano.setCodigo(rst.getInt(1));
              linhaPlano.setDescricao(rst.getString(2));
              listaPlanos.add(linhaPlano);
          }
          
          pst.close();
          conn.close();
          return listaPlanos;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      }
       
   }
   
   public static int codigoNovo(){
       String sql = "Select IDENT_CURRENT('Planos')";
       try{
           Connection conn = Conexao.getConexao();
           PreparedStatement pst = conn.prepareStatement(sql);
           ResultSet rst = pst.executeQuery();
           int codC = 0;
           if(rst.next()){
              codC = rst.getInt(1); 
           }
           return codC + 1;
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage());
           return 0;
       }
   }
   
   public static Plano consultarPlano(int cod){
      String sql = "Select codigo, descricao From Planos Where codigo = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          
          pst.clearParameters();
          pst.setInt(1, cod);
          
          ResultSet rst = pst.executeQuery();
          
          Plano plano = new Plano();
          if(rst.next()){
              plano.setCodigo(rst.getInt(1));
              plano.setDescricao(rst.getString(2));
          }
          
          pst.close();
          conn.close();
          return plano;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao consultar Plano: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return null;
      } 
   }
   
   public static boolean alterar(Plano plano){
      String sql = "Update Planos Set descricao = ? Where codigo = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setString(1, plano.getDescricao());
          pst.setInt(2, plano.getCodigo());
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao alterar: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
   }
   
   public static boolean deletar(int cod){
      String sql = "Delete From Planos Where codigo = ?";
      
      try{
          Connection conn = Conexao.getConexao();
          PreparedStatement pst = conn.prepareStatement(sql);
          pst.clearParameters();
          pst.setInt(1, cod);
          pst.executeUpdate();
          
          pst.close();
          conn.close();
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Erro ao excluir: " + e.getMessage(),"ERRO",JOptionPane.ERROR_MESSAGE);
          return false;
      }
      
      return true;
   }
   
}
